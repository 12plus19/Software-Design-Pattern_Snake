package com.kob.backend.servant;

import com.alibaba.fastjson.JSONObject;
import com.kob.backend.consumer.WebSocketServer;

public class MessageServant {

    public void sendGameResult(Integer playerAId, Integer playerBId, String loser) {
        JSONObject resp = new JSONObject();
        resp.put("event", "result");
        resp.put("loser", loser);

        if (WebSocketServer.users.get(playerAId) != null) {
            WebSocketServer.users.get(playerAId).sendMessage(resp.toJSONString());
        }
        if (WebSocketServer.users.get(playerBId) != null) {
            WebSocketServer.users.get(playerBId).sendMessage(resp.toJSONString());
        }
    }

    public void sendMove(Integer playerAId, Integer playerBId, Integer moveA, Integer moveB) {
        JSONObject resp = new JSONObject();
        resp.put("event", "move");
        resp.put("a_move", moveA);
        resp.put("b_move", moveB);

        if (WebSocketServer.users.get(playerAId) != null) {
            WebSocketServer.users.get(playerAId).sendMessage(resp.toJSONString());
        }
        if (WebSocketServer.users.get(playerBId) != null) {
            WebSocketServer.users.get(playerBId).sendMessage(resp.toJSONString());
        }
    }
}
