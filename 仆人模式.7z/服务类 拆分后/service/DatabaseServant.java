package com.kob.backend.servant;

import com.kob.backend.mapper.RecordMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.Record;
import com.kob.backend.pojo.User;

import java.util.Date;

public class DatabaseServant {

    private final UserMapper userMapper;
    private final RecordMapper recordMapper;

    public DatabaseServant(UserMapper userMapper, RecordMapper recordMapper) {
        this.userMapper = userMapper;
        this.recordMapper = recordMapper;
    }

    public void updateUserRating(Integer userId, Integer rating) {
        User user = userMapper.selectById(userId);
        user.setRating(rating);
        userMapper.updateById(user);
    }

    public void saveRecord(Record record) {
        recordMapper.insert(record);
    }

    public Record createRecord(Integer playerAId, Integer playerBId, String stepsA, String stepsB, String gameMap, String loser) {
        return new Record(
                null,
                playerAId,
                null, null, // 坐标可以补充
                playerBId,
                null, null,
                stepsA,
                stepsB,
                gameMap,
                loser,
                new Date()
        );
    }
}
