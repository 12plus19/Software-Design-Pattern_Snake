package com.kob.backend.servant;

import java.util.Random;

public class GameMapServant {

    public static boolean createWalls(int[][] gameMap, int rows, int cols, int innerWallsCount) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                gameMap[i][j] = 0;
            }
        }
        for (int r = 0; r < rows; r++) {
            gameMap[r][0] = gameMap[r][cols - 1] = 1;
        }
        for (int c = 0; c < cols; c++) {
            gameMap[0][c] = gameMap[rows - 1][c] = 1;
        }
        Random rand = new Random();
        for (int i = 0; i < innerWallsCount / 2; i++) {
            for (int j = 0; j < 1000; j++) {
                int r = rand.nextInt(rows);
                int c = rand.nextInt(cols);
                if (gameMap[r][c] == 1 || gameMap[rows - 1 - r][cols - 1 - c] == 1) {
                    continue;
                }
                gameMap[r][c] = gameMap[rows - 1 - r][cols - 1 - c] = 1;
                break;
            }
        }
        return checkConnectivity(gameMap, rows, cols, rows - 2, 1, 1, cols - 2);
    }

    private static boolean checkConnectivity(int[][] gameMap, int rows, int cols, int sx, int sy, int tx, int ty) {
        if (sx == tx && sy == ty) return true;
        gameMap[sx][sy] = 1;
        int[] dx = {-1, 0, 1, 0};
        int[] dy = {0, 1, 0, -1};
        for (int i = 0; i < 4; i++) {
            int x = sx + dx[i], y = sy + dy[i];
            if (x >= 0 && x < rows && y >= 0 && y < cols && gameMap[x][y] == 0) {
                if (checkConnectivity(gameMap, rows, cols, x, y, tx, ty)) {
                    gameMap[sx][sy] = 0;
                    return true;
                }
            }
        }
        gameMap[sx][sy] = 0;
        return false;
    }
}
