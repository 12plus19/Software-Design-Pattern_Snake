package com.kob.backend.consumer;

import com.alibaba.fastjson.JSONObject;
import com.kob.backend.mapper.BotMapper;
import com.kob.backend.mapper.RecordMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.Bot;
import com.kob.backend.pojo.User;
import com.kob.backend.servant.DatabaseServant;
import com.kob.backend.servant.MessageServant;
import com.kob.backend.utils.JwtUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

@Component
@ServerEndpoint("/websocket/{token}")
public class WebSocketServer {

    public static final ConcurrentHashMap<Integer, WebSocketServer> users = new ConcurrentHashMap<>();
    private User user = null;
    private Session session = null;
    public Game game = null;

    private static UserMapper userMapper;
    private static RecordMapper recordMapper;
    private static BotMapper botMapper;
    public static RestTemplate restTemplate;

    private static final MessageServant messageServant = new MessageServant();

    @Autowired
    public void setUserMapper(UserMapper userMapper) {
        WebSocketServer.userMapper = userMapper;
    }

    @Autowired
    public void setRecordMapper(RecordMapper recordMapper) {
        WebSocketServer.recordMapper = recordMapper;
    }

    @Autowired
    public void setRestTemplate(RestTemplate restTemplate) {
        WebSocketServer.restTemplate = restTemplate;
    }

    @Autowired
    public void setBotMapper(BotMapper botMapper) {
        WebSocketServer.botMapper = botMapper;
    }

    @OnOpen
    public void onOpen(Session session, @PathParam("token") String token) throws IOException {
        System.out.println("连接了一个客户端");
        int userId = -1;
        try {
            Claims claims = JwtUtil.parseJWT(token);
            userId = Integer.parseInt(claims.getSubject());
        } catch (Exception e) {
            e.printStackTrace();
            session.close();
            return;
        }
        this.session = session;
        this.user = userMapper.selectById(userId);
        if (user == null) {
            session.close();
        } else {
            users.put(userId, this);
        }
    }

    @OnClose
    public void onClose() {
        System.out.println("断开了一个客户端的连接");
        if (user != null) {
            users.remove(user.getId());
        }
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("收到来自客户端的信息：" + message);
        JSONObject data = JSONObject.parseObject(message);
        String event = data.getString("event");

        switch (event) {
            case "start-match" -> startMatch(data.getInteger("bot_id"));
            case "stop-match" -> stopMatch();
            case "move" -> move(data.getInteger("d"));
        }
    }

    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    private void move(int d) {
        if (game == null) return;
        if (game.getPlayerA().getId().equals(user.getId())) {
            if (game.getPlayerA().getBotId() == -1) game.setNextStepA(d);
        } else if (game.getPlayerB().getId().equals(user.getId())) {
            if (game.getPlayerB().getBotId() == -1) game.setNextStepB(d);
        }
    }

    private void startMatch(Integer botId) {
        System.out.println("开始匹配...");
        MultiValueMap<String, String> data = new LinkedMultiValueMap<>();
        data.add("userId", user.getId().toString());
        data.add("rating", user.getRating().toString());
        data.add("botId", botId.toString());
        restTemplate.postForObject("http://localhost:3001/player/add/", data, String.class);
    }

    private void stopMatch() {
        System.out.println("停止匹配...");
        MultiValueMap<String, String> data = new LinkedMultiValueMap<>();
        data.add("userId", user.getId().toString());
        restTemplate.postForObject("http://localhost:3001/player/remove/", data, String.class);
    }

    public void sendMessage(String message) {
        synchronized (session) {
            try {
                session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void startGame(Integer aId, Integer aBotId, Integer bId, Integer bBotId) {
        User a = userMapper.selectById(aId);
        User b = userMapper.selectById(bId);
        Bot aBot = botMapper.selectById(aBotId);
        Bot bBot = botMapper.selectById(bBotId);

        Game game = new Game(13, 13, 20, a.getId(), aBot, b.getId(), bBot);
        game.createGameMap();

        if (users.get(a.getId()) != null) {
            users.get(a.getId()).game = game;
        }
        if (users.get(b.getId()) != null) {
            users.get(b.getId()).game = game;
        }

        game.start();
    }
}
