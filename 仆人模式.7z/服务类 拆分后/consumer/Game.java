package com.kob.backend.consumer;

import com.kob.backend.pojo.Bot;
import com.kob.backend.pojo.Record;
import com.kob.backend.servant.DatabaseServant;
import com.kob.backend.servant.GameMapServant;
import com.kob.backend.servant.MessageServant;

import java.util.Date;

public class Game extends Thread {

    private final int[][] gameMap;
    private final Player playerA;
    private final Player playerB;

    private final GameMapServant gameMapServant = new GameMapServant();
    private final DatabaseServant databaseServant;
    private final MessageServant messageServant = new MessageServant();

    private String status = "playing"; // 游戏状态
    private String loser = "";         // 输家

    public Game(int rows, int cols, int innerWallsCount, Integer idA, Bot aBot, Integer idB, Bot bBot) {
        this.gameMap = new int[rows][cols];
        this.playerA = new Player(idA, aBot);
        this.playerB = new Player(idB, bBot);

        databaseServant = new DatabaseServant(WebSocketServer.userMapper, WebSocketServer.recordMapper);
    }

    public void createGameMap() {
        gameMapServant.createWalls(gameMap, 13, 13, 20);
    }

    private void judge() {
        boolean validA = playerA.checkMove(gameMap);
        boolean validB = playerB.checkMove(gameMap);

        if (!validA || !validB) {
            status = "finished";
            if (!validA && !validB) {
                loser = "all";
            } else if (!validA) {
                loser = "A";
            } else {
                loser = "B";
            }
        }
    }

    @Override
    public void run() {
        while ("playing".equals(status)) {
            judge();
            if ("finished".equals(status)) {
                saveGameResult();
                break;
            }
        }
    }

    private void saveGameResult() {
        Record record = databaseServant.createRecord(playerA.getId(), playerB.getId(), "stepsA", "stepsB", "mapData", loser);
        databaseServant.saveRecord(record);
        messageServant.sendGameResult(playerA.getId(), playerB.getId(), loser);
    }
}
